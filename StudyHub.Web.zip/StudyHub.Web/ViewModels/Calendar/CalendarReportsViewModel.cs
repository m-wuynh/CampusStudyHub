using System.Collections.Generic;

namespace StudyHub.Web.ViewModels.Calendar;

public sealed class CategoryStatItemDto
{
    public string CategoryName { get; set; } = string.Empty;
    public int TotalEvents { get; set; }
    public double PercentageOfTotal { get; set; }
    public int CompletedEvents { get; set; }
    public int CompletionPct { get; set; }
    public int MissedEvents { get; set; }
    public string StatusBadge { get; set; } = "Bình thường";
    public string StatusBadgeType { get; set; } = "primary"; // "success", "warning", "primary"
}

public sealed class CalendarReportsViewModel
{
    public string Range { get; set; } = "this-week";
    public string RangeLabel { get; set; } = "Tuần này";
    public string DateRangeText { get; set; } = string.Empty;
    public int TotalEvents { get; set; }
    public double AvgPerDay { get; set; }
    public int CompletedEvents { get; set; }
    public int CompletionPct { get; set; }
    public int MissedEvents { get; set; }
    public int UpcomingEvents { get; set; }
    
    // Category Breakdown (Section B)
    public List<CategoryStatItemDto> CategoryStats { get; set; } = new();

    // Smart Insight (Section C)
    public string InsightTitle { get; set; } = string.Empty;
    public string InsightMessage { get; set; } = string.Empty;
    public string InsightBadge { get; set; } = string.Empty;
    public string InsightBadgeType { get; set; } = "success"; // "success", "warning", "info", "danger"
    public string InsightRecommendation { get; set; } = string.Empty;
}
