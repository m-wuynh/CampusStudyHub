using StudyHub.BLL.DTOs;

namespace StudyHub.BLL.Services.Calendar;

public interface ICalendarService
{
    Task<List<ScheduleEventDto>> GetEventsAsync(long userId, DateOnly fromDate, DateOnly toDate);
    Task<ScheduleEventDto?> GetEventAsync(long userId, long id);
    Task<ScheduleEventDto> CreateEventAsync(long userId, CreateEventDto request);
    Task UpdateEventAsync(long userId, UpdateEventDto request);
    Task DeleteEventAsync(long userId, long id);
    Task<List<ScheduleEventDto>> GetActiveRemindersAsync(long userId);
    Task<List<int>> GetReminderMinutesAsync(long userId, long eventId);
    Task<List<ReminderInputDto>> GetEventRemindersAsync(long userId, long eventId);
    Task ToggleEventCompletionAsync(long userId, long eventId, bool isCompleted);
    Task<bool> ToggleEventCompletionAsync(long userId, long id);
    Task<List<ScheduleEventDto>> SearchEventsAsync(long userId, string keyword, int maxResults = 20);
    Task<List<CalendarCategoryDto>> GetCategoriesAsync(long userId);
    Task<CalendarCategoryDto> CreateCategoryAsync(long userId, SaveCalendarCategoryDto request);
    Task UpdateCategoryAsync(long userId, long categoryId, SaveCalendarCategoryDto request);
    Task DeleteCategoryAsync(long userId, long categoryId);
}
